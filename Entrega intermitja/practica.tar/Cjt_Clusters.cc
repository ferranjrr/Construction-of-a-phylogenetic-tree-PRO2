#include "Cjt_Clusters.hh"
/*
void Cjt_Clusters::escriure_taula_distancies() {
    //Imprimeix en el canal estàndard de sortida la taula de distancies utilitzant els identifiacors dels clústers per indexar les files i les columnes.
}

void Cjt_Clusters::afegir_cluster(string id) {
    //ha de cridar al constructor Cluster(string id) de la classe Cluster.
}
*/
