#include "Cluster.hh"
/*
Cluster Cluster::fusionar_clusters(const Cluster& a, const Cluster& b) {
    //La pots declarar static (però no és obligat, perquè un dels dos clusters d'entrada podria ser el paràmetre implícit i llavors seria consultora).
}
*/
