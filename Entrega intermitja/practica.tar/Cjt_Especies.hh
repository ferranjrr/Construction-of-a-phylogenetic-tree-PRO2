/** @file Cjt_Especies.hh
    @brief Especificació de la clase Conjunt d'Espècies
*/
#ifndef CJT_ESPECIES_HH
#define CJT_ESPECIES_HH

#include "Especie.hh"
//#include "Cjt_Clusters.hh"

#ifndef NO_DIAGRAM

#include <iostream>
#include <map>
using namespace std;

#endif

/** @class Cjt_Especies
 *  @brief Representa un conjunt d'espècies
 * 
 *  Hi ha operacions per afegir i treure espècies del conjunt. Es pot consultar si una certa espècie hi és, consultar el <em>gen</em> d'una espècie donat un cert <em>id</em> i consultar la distància entre dues espècies del conjunt. El conjunt d'espècies té associada una taula de distancies entre les espècies del conjunt, que s'actualitza cada cop que s'afegeix/elimina una espècie. Les distancies són calculades segons el criteri de clàlcul que indica l'enter <em>k</em> >= 1. Totes les espècies del conjunt tenen les sequències <em>kmer</em> calculats.(HO POSO??)
 * Ofereix operacions de lecutra i escriptura del conunt i de la taula de distàncies.
 * 
*/

class Cjt_Especies {
    
private:
    map<string,Especie> esp;
    //Conjunt d'espècies on la clau és id.
    map< string, map<string,double> > dist;// taula de distàncies. Les claus són l'id de cada espècie i el double és la distància de la clau del primer map a la clau del segon map.
    
    int k; //criteri de distàncies
    
    /*Invariant:
        k >= 1
    */
    
    
    
    //genera la taula de distancies dist. Si estaba plena, es buida i es torna a omplir.
void generar_taula_distancies();

    //afageix i actualitza les distancies donat una especie e que entrerà al conjunt;
void afegir_especie_taula_distancies(const Especie& e);

    //elimina i acutlaitza les distancies donat un id
void eliminar_especie_taula_distancies(string id);
    
public:

    //Constructores
    
/** @brief Creadora per defecte
    \pre <em>k</em> >= 1
    \post Crea un Conjunt d'Espècies buit i associa k al p.i.
*/
    Cjt_Especies(int k);
    
    
    //Destructora
    
/** @brief Destructora per defecte */   
    ~Cjt_Especies();
    
    
    //Modificadores
    
/** @brief Afegeix una espècie al p.i
    \pre <em>id</em> és l'identificador de la espècie <em>e</em>; No hi ha cap espècie al p.i. amb <em>id</em> = <em>ID</em>. 
    \post S'ha afegit <em>e</em> al p.i i <em>e</em> té calculat el <em>kmer</em>. S'ha actualitzat la taula de distàncies.
*/
void afegir_especie(Especie e);


/** @brief Elimina una espècie del p.i.
    \pre Hi ha una espècie al p.i. amb <em>ID</em> = <em>id</em> 
    \post El p.i. queda sense l'espècie amb identificador <em>ID</em>; S'ha actualitzat la taula de distàncies
*/
void eliminar_especie(string id);


    //Consultores

/** @brief Consulta si hi ha una espècie al paràmetre implícit
    \pre  <em>Cert</em> 
    \post Si retorna <em>true</em> significa que hi ha una espècie en el p.i. amb <em>ID</em>=<em>id</em>, <em>fals</em> altrament
*/
bool hi_es(string id) const;


/** @brief Consultora del gen a través de id
    \pre Existeix una espècie amb <em>ID</em> = <em>id</em> 
    \post Retorna el <em>gen</em> de la espècie de <em>ID</em>
*/
string consultar_gen(string id) const;


/** @brief Consultora de la distància entre dos espècies
    \pre Existeix una espècie en el p.i. amb <em>ID1</em> = <em>id1</em> i una altra amb <em>ID2</em> = <em>id2</em>
    \post Retorna la distància entre elles
*/
double consultar_distancia(string id1, string id2) const;


/** @brief Omplir el cjt_Clusters
    \pre <em>Cert</em> 
    \post Cjt_Especies queda omplert amb les espècies del paràmetre implícit. S'han actualitzat totes les distàncies?
*/
//void omplir_cjt_clusters(Cjt_Clusters& clu) const;


    //Lectura y escriptura

/** @brief Operació de lecutra
    \pre Hi ha preparats al canal estàndard d'entrada un enter n ≥ 0 i a continuació una sequència de n espècies (parells de identificador-gen); Les n espècies donades tenen identificadors diferents entre si
    \post El conjunt previ d'espècies es descarta —les espècies deixen d'existir— i les n espècies llegides s'agreguen al conjunt de espècies. Cada espècie té els <em>kmer</em> calculats. Es buida la taula de distàncies i s'actualitza amb les noves espècies llegides.
*/
void llegir();


/** @brief Operació d'escriptura de la taula de distàncies
    \pre <em>Cert</em> 
    \post Imprimeix en el canal estàndard de sortida la taula de distàncies entre cada parell d'espècies del p.i.
*/
void escriure_taula_distancies() const;


/** @brief Operació d'escriptura del conjunt d'espècies
    \pre <em>Cert</em> 
    \post Imprimeix en el canal estàndard de sortida el conjunt d'especies (identificador i gen de cada una). Si p.i. és buit, no imprimeix res
*/
void escirure() const;

};

#endif
