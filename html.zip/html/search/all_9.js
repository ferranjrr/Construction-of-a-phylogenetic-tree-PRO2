var searchData=
[
  ['llegir',['llegir',['../class_cjt___especies.html#a2a0658d5acd67177881acc6f621fe2c0',1,'Cjt_Especies::llegir()'],['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie::llegir()']]]
];
