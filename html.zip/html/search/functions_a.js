var searchData=
[
  ['omple_5ftaula_5fdistancies',['omple_taula_distancies',['../class_cjt___clusters.html#af1bf97b420bf3933bfe2ba9904e01241',1,'Cjt_Clusters']]],
  ['omplir_5fcjt_5fclusters',['omplir_cjt_clusters',['../class_cjt___especies.html#a311090cf3df21cf719ab4419a662d9aa',1,'Cjt_Especies']]]
];
