var searchData=
[
  ['gen',['gen',['../class_especie.html#ac35bb565f7346cd6317b3a8c849456d1',1,'Especie']]],
  ['generar_5ftaula_5fdistancies',['generar_taula_distancies',['../class_cjt___especies.html#a9437508ef6176d867e0bb7fbf4ba3106',1,'Cjt_Especies']]]
];
