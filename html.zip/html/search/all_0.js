var searchData=
[
  ['actualitzar_5ftaula_5fdistancies',['actualitzar_taula_distancies',['../class_cjt___clusters.html#a15ac7653c39fe7ed1f2e21debeb3b24b',1,'Cjt_Clusters']]],
  ['afegir_5fcluster',['afegir_cluster',['../class_cjt___clusters.html#a195166b0ac52530dadc9c883c206a01c',1,'Cjt_Clusters']]],
  ['afegir_5fespecie',['afegir_especie',['../class_cjt___especies.html#aa70101c5e157fd855475248c174e41f1',1,'Cjt_Especies']]],
  ['afegir_5fespecie_5ftaula_5fdistancies',['afegir_especie_taula_distancies',['../class_cjt___especies.html#aed10769d0831e7b92fb0a602bce7766a',1,'Cjt_Especies']]],
  ['aplicar_5falgorisme_5fwpgma',['aplicar_algorisme_WPGMA',['../class_cjt___clusters.html#aa4de01f6c66018acd6ac04f9686f0a17',1,'Cjt_Clusters']]]
];
