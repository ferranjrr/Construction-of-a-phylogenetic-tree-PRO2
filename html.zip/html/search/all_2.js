var searchData=
[
  ['dist',['dist',['../class_cjt___clusters.html#afde449634787205786301b40e053fe91',1,'Cjt_Clusters::dist()'],['../class_cjt___especies.html#aaf5d15b706e8b0c5b910283d60ef58a6',1,'Cjt_Especies::dist()']]]
];
