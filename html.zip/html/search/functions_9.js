var searchData=
[
  ['numero_5fclusters',['numero_clusters',['../class_cjt___clusters.html#ac8f1dc8aefd1619f4a78c04624dedcc0',1,'Cjt_Clusters']]]
];
