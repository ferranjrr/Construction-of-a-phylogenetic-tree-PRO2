var searchData=
[
  ['k',['k',['../class_cjt___especies.html#a4586fb4724b7af4b7f00bb0c0bdd6a17',1,'Cjt_Especies']]],
  ['kmer',['kmer',['../class_especie.html#ab6740db160f2d7335a98fa8d9f745cbe',1,'Especie']]]
];
